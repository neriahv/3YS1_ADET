import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    
    final appTitle = 'Flutter Basic Card Demo';

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: appTitle,
      home: Scaffold (
        appBar: AppBar (
          title: Text(appTitle),
        ),
        body: ListView(
          children: <Widget>[
            Card(
              child: ListTile(
                leading: Icon(Icons.map),
                title: Text('Map'),
              ),
            ),
            Card(
              child: ListTile(
                leading: Icon(Icons.photo_album), 
                title: Text('Album')
                )
                ),
            Card(
              child: ListTile(
                leading: Icon(Icons.phone), 
                title: Text('Phone')
                )
                ),
            Card(
              child: ListTile(
                leading: Icon(Icons.contacts), 
                title: Text('Contact')
                )
                ),
            Card(
              child: ListTile(
                leading: Icon(Icons.settings), 
                title: Text('Setting')
                )
                ),
          ],
        ),
      ),
    );
  }
}