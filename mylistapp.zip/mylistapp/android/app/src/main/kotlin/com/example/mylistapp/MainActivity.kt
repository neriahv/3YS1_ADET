package com.example.mylistapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
